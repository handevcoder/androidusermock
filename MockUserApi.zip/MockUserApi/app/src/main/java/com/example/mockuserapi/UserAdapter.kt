package com.example.mockuserapi

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.mockuserapi.databinding.ItemUsersBinding
import com.example.mockuserapi.model.UserModel

class UserAdapter(private val context: Context) : RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    var list = mutableListOf<UserModel>()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    fun addUsers(users: List<UserModel>) {
        val firstIndex = list.lastIndex + 1
        list.addAll(users)
        notifyItemRangeInserted(firstIndex, list.lastIndex)
    }

    inner class ViewHolder(private val binding: ItemUsersBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bindData(result: UserModel) {
            with(binding) {
                Glide.with(root).load(result.picture.medium).into(ivPicture)
                tvName.text = "${result.name.first} ${result.name.last}"
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserAdapter.ViewHolder {
        return ViewHolder(ItemUsersBinding.inflate(
                LayoutInflater.from(context), parent, false))
    }

    override fun onBindViewHolder(holder: UserAdapter.ViewHolder, position: Int) {
        holder.bindData(list[position])
    }

    override fun getItemCount(): Int = list.size


}
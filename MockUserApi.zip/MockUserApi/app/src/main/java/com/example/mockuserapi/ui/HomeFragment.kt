package com.example.mockuserapi.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.mockuserapi.R
import com.example.mockuserapi.databinding.FragmentHomeBinding

class HomeFragment : Fragment() {
    private lateinit var binding: FragmentHomeBinding
    private val fragments by lazy {
        listOf(UserFragment(), FavoritFragment(), ProfileFragment())
    }
    private val adapter by lazy {
        ViewPagerAdapter(fragments, childFragmentManager, lifecycle)
    }

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false).apply {
            vpHome.adapter = adapter
            bnvHome.setOnNavigationItemSelectedListener {
                when (it.itemId) {
                    R.id.menuUser -> {
                        vpHome.currentItem = 0
                        return@setOnNavigationItemSelectedListener true
                    }
                    R.id.menuUser -> {
                        vpHome.currentItem = 1
                        return@setOnNavigationItemSelectedListener true
                    }
                    R.id.menuProfile -> {
                        vpHome.currentItem = 2
                        return@setOnNavigationItemSelectedListener true
                    }
                }
                false
            }
        }
        return binding.root
    }
}
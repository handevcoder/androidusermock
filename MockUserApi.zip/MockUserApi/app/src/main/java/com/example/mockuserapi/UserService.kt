package com.example.mockuserapi

import com.example.mockuserapi.model.User
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface UserService {
    @GET("api/")
    fun getAllUsers(
        @Query("results") results: Int = 100,
        @Query("inc") inc: String = "name,phone,cell,picture"
    ): Call<User>
}
package com.example.mockuserapi.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.mockuserapi.DataBinderMapperImpl
import com.example.mockuserapi.LocalStorage
import com.example.mockuserapi.R
import com.example.mockuserapi.databinding.FragmentRegisterBinding

class RegisterFragment : Fragment() {
    private lateinit var binding: FragmentRegisterBinding
    private val localStorage by lazy {
        LocalStorage(requireContext())
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        binding = FragmentRegisterBinding.inflate(inflater, container, false).apply {
            btnLogin.setOnClickListener { findNavController().navigate(R.id.action_registerFragment_to_loginFragment) }
            btnReg.setOnClickListener { validateData() }
        }
        return binding.root
    }

    private fun validateData() {
        val name = binding.tieName.text.toString()
        val email = binding.tieEmail.text.toString()
        val password = binding.tiePassword.text.toString()

        when{
            name.isName() && email.isEmail() && password.isPassword()
            -> {
                localStorage.saveName(name)
                localStorage.saveEmail(email)
                localStorage.savePassword(password)
                Toast.makeText(requireContext(), "Berhasil mendaftar", Toast.LENGTH_SHORT).show()
                findNavController().navigate(R.id.action_registerFragment_to_loginFragment)
            }
            else -> {
                Toast.makeText(requireContext(), "Semua kolom wajib diisi", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
package com.example.mockuserapi.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import com.example.mockuserapi.LocalStorage
import com.example.mockuserapi.R
import com.example.mockuserapi.databinding.FragmentLoginBinding

class LoginFragment : Fragment() {
    private lateinit var binding: FragmentLoginBinding
    private val localStorage by lazy {
        LocalStorage(requireContext())
    }

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        binding = FragmentLoginBinding.inflate(inflater, container, false).apply {
            btnLogin.setOnClickListener { validateData() }
            btnReg.setOnClickListener {
                findNavController().navigate(R.id.action_loginFragment_to_registerFragment)
            }
        }
        if (localStorage.getAuth()) moveToHome()
        return binding.root
    }

    private fun validateData() {
        val email = binding.tieEmail.text.toString()
        val password = binding.tiePassword.text.toString()

        when {
            email.isEmail() && password.isPassword() -> {
                localStorage.saveAuth(true)

                Toast.makeText(requireContext(), "Berhasil Masuk", Toast.LENGTH_SHORT).show()

                moveToHome()
            }
            else -> {
                Toast.makeText(requireContext(), "Semua kolom wajib diisi", Toast.LENGTH_SHORT)
                        .show()
            }
        }
    }


    private fun moveToHome() {
        findNavController().navigate(R.id.action_loginFragment_to_homeFragment)
    }
}